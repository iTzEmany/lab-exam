#include "header.h"

// Declaration of the calculator structure
calculator cal;

// Buffer to store the result received from the server
char *res;

// Variable to store the return value of send/recv functions
int flag;

void clearConsole() {
#ifdef _WIN32
    system("cls");  // For Windows
#else
    system("clear");  // For macOS and Linux
#endif
}

int main() {

#ifdef _WIN32
    // Windows-specific: Initialize Winsock
    WSADATA wsaData;
    SOCKET clientSocket;
#else
    // Unix/Linux-specific: Use int for socket descriptor
    int clientSocket;
#endif

    // Structure to hold server address information
    struct sockaddr_in serverAddr;

#ifdef _WIN32
    // Windows-specific: Check for Winsock initialization errors
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("Error initializing Winsock\n");
        return 1;
    }
#endif

    // Create a socket
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == -1) {
        printf("Error creating socket\n");
        return 1;
    }

    // Configure server address
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(SERVER_ADDRESS);
    serverAddr.sin_port = htons(PORT);

    // Connect to the server
    if (connect(clientSocket, (struct sockaddr*) &serverAddr,
                sizeof(serverAddr)) == -1) {
        printf("Error connecting to the server\n");
        return 1;
    }

    // Main loop for user input and communication with the server
    while (1) {
        // Prompt user for input
        puts("Enter the operands in this order (operator operand operand)");
        puts("Digit '=' as the operator to interrupt the connection with the server");
        printf("Digit: ");

        // Read user input
        scanf("%s %s %s", cal.operator, cal.op1, cal.op2);
        fflush(stdin);

        if(strcmp(cal.operator, "=")==0){
        	puts("Program terminated");
        	getch();
        	break;
        }
        // Allocate memory for the result buffer
        res = malloc(sizeof(char[BUFFSIZE]));

        // Send calculator structure to the server
        if (send(clientSocket, (char*) &cal, sizeof(calculator), 0) == -1) {
            perror("Error sending data");
        }

        // Receive the result from the server
        if ((flag = recv(clientSocket, res, BUFFSIZE, 0)) == -1) {
            perror("Error receiving data");
        } else if (flag == 0) {
            printf("The server has closed the connection\n");
            break;
        } else {
            // Print the result
            printf("The result is: %s\n", res);
        }
        puts("Press any key to continue");
        getch();
        clearConsole();
        // Clear the result buffer
        memset(res, '\0', BUFFSIZE);
    }

    // Close the socket
#ifdef _WIN32
    closesocket(clientSocket);
#else
    close(clientSocket);
#endif

#ifdef _WIN32
    // Windows-specific: Cleanup Winsock
    WSACleanup();
#endif
    free(res);
    return 0;
}
