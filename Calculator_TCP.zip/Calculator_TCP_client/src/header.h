#ifndef HEADER_H_
#define HEADER_H_

#ifdef _WIN32
// Include Windows Sockets library for Windows platform
#include <winsock.h>
#else
// Include necessary headers for Unix/Linux platform
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <termios.h>
#include <unistd.h>

// Define a macro to substitute closesocket with close on Unix/Linux
#define closesocket close
#endif

// Include standard C libraries
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>  // This is a Windows-specific header, consider removing or replacing
#include <string.h>
#include <stdbool.h>

// Define constants for the program
#define PORT 80
#define BUFFSIZE 1024
#define SERVER_ADDRESS "127.0.0.1"
#define MAXLENGHT 10

// Define a structure for the calculator
typedef struct {
    char operator[MAXLENGHT];
    char op1[MAXLENGHT];
    char op2[MAXLENGHT];
} calculator;

#endif
