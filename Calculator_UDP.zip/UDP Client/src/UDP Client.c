#include "header.h"

// Function to clean up Winsock resources
void clearwinsock() {
#if defined WIN32
    WSACleanup();
#endif
}

// Function to clear the screen
void clearScreen() {
#if defined WIN32
    system("cls");
#else
    system("clear");
#endif
}

// Function to handle errors
void errorhandler(const char *error_message) {
    printf("%s\n", error_message);
}

// Main function with command line arguments
int main(int argc, char *argv[]) {
#if defined WIN32
    // Initialize Winsock
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != NO_ERROR) {
        printf("Error at WSAStartup()\n");
        return 0;
    }
#endif

    // Allocate memory for the buffer
    char* buffer = malloc(BUFFMAX);
    char serverName[BUFFMAX];
    int port;

    // Check if command line arguments are provided
    if (argc == 3) {
        // Use provided values
        strcpy(serverName, argv[1]);
        port = atoi(argv[2]);
    } else {
        // Use default values if not provided
        strcpy(serverName, "srv.di.uniba.it");
        port = 56700;
    }

    // Get host information
    struct hostent *host = gethostbyname(serverName);
    if (host == NULL) {
        errorhandler("Error getting host");
        clearwinsock();
        free(buffer);
        return EXIT_FAILURE;
    }

    // Create a UDP socket
    int my_socket;
    struct sockaddr_in server_address;
    int server_address_size = sizeof(server_address);
    int rcv_msg_size;

    if ((my_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
        errorhandler("Error creating socket");
        clearwinsock();
        free(buffer);
        return EXIT_FAILURE;
    }

    // Set server address
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(port);
    server_address.sin_addr = *((struct in_addr*) host->h_addr);

    while (1) {
        // Clear the screen and display server information
        clearScreen();
        printf("Server name: %s (IP: %s, port: %d)\n", serverName, inet_ntoa(*(struct in_addr*) host->h_addr), port);
        puts("Enter the operands in this order (operator operand operand)");
        puts("Digit '=' as the operator to interrupt the connection with the server");
        printf("Digit: ");

        // Read input from the user
        memset(buffer, 0, BUFFMAX);
        fgets(buffer, BUFFMAX, stdin);
        buffer[strlen(buffer)-1]='\0';

        // Check for termination condition
        if(buffer[0] == '=' && buffer[1] == ' '){
            puts("Client terminated. Press any key to continue...");
            getch();
            closesocket(my_socket);
            clearwinsock();
            free(buffer);
            return EXIT_FAILURE;
        }

        // Send data to the server
        if (sendto(my_socket, buffer, strlen(buffer), 0, (struct sockaddr*) &server_address, sizeof(server_address)) != strlen(buffer)) {
            errorhandler("Error sending data");
            closesocket(my_socket);
            clearwinsock();
            free(buffer);
            return EXIT_FAILURE;
        }

        // Receive data from the server
        memset(buffer, 0, BUFFMAX);
        if ((rcv_msg_size = recvfrom(my_socket, buffer, BUFFMAX, 0, (struct sockaddr*) &server_address, &server_address_size)) < 0) {
            errorhandler("Error receiving data");
            closesocket(my_socket);
            clearwinsock();
            free(buffer);
            return EXIT_FAILURE;
        }

        // Display received message
        printf("Message received from %s, ip %s: %s\n", inet_ntoa(*(struct in_addr*) host->h_addr), inet_ntoa(*(struct in_addr*) host->h_addr), buffer);
        puts("Press any key to continue...");
        getch();
    }

    // Close the socket and clean up resources
    closesocket(my_socket);
    clearwinsock();
    free(buffer);
    return EXIT_SUCCESS;
}
