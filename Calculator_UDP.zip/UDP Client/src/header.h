/*
 * header.h
 *
 *  Created on: 11 dic 2023
 *      Author: manul
 */

#ifndef HEADER_H_
#define HEADER_H_

#if defined WIN32
#include <winsock.h>
#include <windows.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

#define NO_ERROR 0
#define BUFFMAX 255


#endif /* HEADER_H_ */
