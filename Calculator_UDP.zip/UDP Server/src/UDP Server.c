#include "header.h"

// Global variable for the buffer
char* buffer;

// Function to clean up Winsock resources
void clearwinsock() {
#if defined WIN32
    WSACleanup();
#endif
}

// Function to handle errors
void errorhandler(char *error_message) {
    printf("%s", error_message);
}

// Function to clear the screen
void cleanScreen() {
#if defined WIN32
    system("cls");
#else
    system("clear");
#endif
}

// Function to check if all characters in operands are numeric
int areAllNumericChars(char* ope1, char* ope2) {
    const char *app[] = {ope1, ope2};
    int size = sizeof(app) / sizeof(app[0]);

    for (int i = 0; i < size; i++) {
        const char *str = app[i];
        int dotCount = 0;

        while (*str) {
            if (!isdigit(*str)) {
                if (*str == '.') {
                    dotCount++;

                    if (dotCount > 1 || *(str + 1) == '\0') {
                        return 1;
                    }
                } else {
                    return 1;
                }
            }
            str++;
        }
    }
    return 0;
}

// Function to perform addition
void add(char* ope1, char* ope2) {
    sprintf(buffer, "%s + %s = %.2f", ope1, ope2, (float) atof(ope1) + (float) atof(ope2));
}

// Function to perform subtraction
void sub(char* ope1, char* ope2) {
    sprintf(buffer, "%s - %s = %.2f", ope1, ope2, (float) atof(ope1) - (float) atof(ope2));
}

// Function to perform multiplication
void mult(char* ope1, char* ope2) {
    sprintf(buffer, "%s * %s = %.2f", ope1, ope2, (float) atof(ope1) * (float) atof(ope2));
}

// Function to perform division
void division(char* ope1, char* ope2) {
    float op2 = atof(ope2);
    if (op2 != 0) {
        sprintf(buffer, "%s / %s = %.2f", ope1, ope2, (float) atof(ope1) / (float) atof(ope2));
    } else {
        strcpy(buffer, "Error: Division by zero\n");
    }
}

int main(void) {
#if defined WIN32
    // Initialize Winsock
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != NO_ERROR) {
        printf("Error at WSAStartup()\n");
        return 0;
    }
#endif

    int my_socket;

    /* create a UDP socket */
    if ((my_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
        errorhandler("Error creating socket");
        clearwinsock();
        return EXIT_FAILURE;
    }

    /* set the server address */
    struct sockaddr_in server_address;
    struct sockaddr_in client_address;
    int client_address_length = sizeof(client_address);
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(PORT);
    server_address.sin_addr.s_addr = inet_addr("127.0.0.1");

    /* set server address */
    if ((bind(my_socket, (struct sockaddr*) &server_address, sizeof(server_address))) < 0) {
        errorhandler("bind() failed");
        closesocket(my_socket);
        clearwinsock();
        return EXIT_FAILURE;
    }
    char* operator = malloc(BUFFMAX);
    char* operand1 = malloc(BUFFMAX);
    char* operand2 = malloc(BUFFMAX);
    buffer = malloc(BUFFMAX);
    int rcv_msg_size;
    while (1) {
        puts("\nServer listening...");

        /* receive data from the client */
        memset(buffer, 0, BUFFMAX);
        if ((rcv_msg_size = recvfrom(my_socket, buffer, BUFFMAX, 0, (struct sockaddr*) &client_address, &client_address_length)) < 0) {
            errorhandler("recvfrom() data failed");
            closesocket(my_socket);
            clearwinsock();
            free(buffer);
            free(operator);
            free(operand1);
            free(operand2);
            return EXIT_FAILURE;
        }
        struct hostent *client_host = gethostbyaddr((char*) &client_address.sin_addr.s_addr, sizeof(client_address.sin_addr.s_addr), AF_INET);
        printf("Request for operation '%s' from the client %s (IP %s, port %d)\n", buffer, client_host->h_name, inet_ntoa(client_address.sin_addr), ntohs(client_address.sin_port));
        /* remove vowels from buffer and send it back to the client */

        if (sscanf(buffer, "%s %s %s", operator, operand1, operand2) == 3) {
            // Check if the operands are numeric
            if (areAllNumericChars(operand1, operand2) != 1) {
                // Perform the appropriate mathematical operation based on the operator
                if (strcmp(operator, "+") == 0) {
                    add(operand1, operand2);
                } else if (strcmp(operator, "-") == 0) {
                    sub(operand1, operand2);
                } else if (strcmp(operator, "x") == 0) {
                    mult(operand1, operand2);
                } else if (strcmp(operator, "/") == 0) {
                    division(operand1, operand2);
                } else {
                    // If the operator is not recognized, set an error message
                    strcpy(buffer, "This mathematical operation is invalid");
                }
            } else {
                // If operands are not numeric, set an error message
                strcpy(buffer, "This mathematical operation is invalid");
            }
        } else {
            strcpy(buffer, "This mathematical operation is invalid");
        }
        printf("Sending '%s' back to client\n", buffer);
        if (sendto(my_socket, buffer, strlen(buffer), 0, (struct sockaddr*) &client_address, sizeof(client_address)) != strlen(buffer)) {
            errorhandler("sendto() sent a different number of bytes than expected");
            closesocket(my_socket);
            clearwinsock();
            free(buffer);
            free(operator);
            free(operand1);
            free(operand2);
            return EXIT_FAILURE;
        }
    }
}
